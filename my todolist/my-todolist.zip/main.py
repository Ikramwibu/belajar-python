print("My Todolist")
print("=============")

active = True

while active:
  todo = input("apa yang anda ingin lakukan: ")

  file = open("todolist.txt", "a")
  file.write(todo+"\n")
  file.close()

  file = open("todolist.txt", "r")
  print(file.read())
  
  active = input("ingin lanjut? y/n: ")